# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractor import LinkExtractor
from scrapy.spiders import Rule, CrawlSpider
from newsspider_scraper.items import NewsspiderScraperItem


class NewsspiderSpider(scrapy.Spider):
    name = 'newsspider'
    allowed_domains = ['independent.ie']
    start_urls = ['http://independent.ie/Sport',
                  'https://www.independent.ie/news/',
                  'https://www.independent.ie/entertainment/'

                  ]

   def parse(self, response): 
      filename = response.url.split("/")[-2] + '.html' 
      with open(filename, 'wb') as f: 
         f.write(response.body)
